"""
rules.py - 分类规则模块

定义文件分类的规则映射：
1. 关键字规则（优先级高）：文件名包含特定关键字 → homework
2. 后缀名规则（优先级低）：按扩展名分类到对应目录
"""

from pathlib import Path

# 如果文件名包含以下关键字，优先归类到 homework
HOMEWORK_KEYWORDS = ["作业", "练习", "实验", "任务"]

# 后缀名 → 目标目录 的映射规则
EXTENSION_MAP = {
    # 课件
    ".ppt": "slides",
    ".pptx": "slides",
    ".key": "slides",
    # 代码
    ".py": "code",
    ".ipynb": "code",
    ".c": "code",
    ".cpp": "code",
    ".java": "code",
    # 数据
    ".csv": "data",
    ".xlsx": "data",
    ".json": "data",
    # 文档
    ".pdf": "documents",
    ".doc": "documents",
    ".docx": "documents",
    ".txt": "documents",
    ".md": "documents",
    # 图片
    ".png": "images",
    ".jpg": "images",
    ".jpeg": "images",
    ".gif": "images",
}


def get_category(file_path: Path) -> str:
    """
    根据文件名和后缀名确定文件应归属的分类目录。

    优先级：
        1. 文件名关键字匹配 → 'homework'
        2. 后缀名匹配 → EXTENSION_MAP 对应目录
        3. 均不匹配 → 'others'

    Args:
        file_path: Path 对象，表示文件路径

    Returns:
        str: 目标目录名称，如 'homework', 'slides', 'code' 等
    """
    # 第一步：检查文件名是否包含 homework 关键字
    # 使用原始文件名（不含路径和扩展名）进行匹配
    file_stem = file_path.stem  # 例如 "Python第01讲_作业说明"

    for keyword in HOMEWORK_KEYWORDS:
        if keyword in file_stem:
            return "homework"

    # 第二步：检查后缀名
    ext = file_path.suffix.lower()  # 统一转为小写，如 '.PDF' → '.pdf'
    if ext in EXTENSION_MAP:
        return EXTENSION_MAP[ext]

    # 第三步：无法识别的类型
    return "others"
