"""
core.py - 核心逻辑模块

负责：
    - 扫描源目录中的文件
    - 根据规则生成分类计划
    - 执行文件复制（支持 dry-run 预览）
    - 处理重名冲突（自动加序号）
    - 生成 CSV 格式的整理报告
"""

import shutil
import csv
from pathlib import Path
from datetime import datetime

from .rules import get_category


def scan_source(source_dir: Path) -> list[Path]:
    """
    扫描源目录，返回其中所有文件的 Path 列表。
    只扫描当前目录，不递归子目录。

    Args:
        source_dir: 源目录 Path 对象

    Returns:
        list[Path]: 文件路径列表
    """
    files = []
    if source_dir.exists() and source_dir.is_dir():
        for item in source_dir.iterdir():
            if item.is_file():
                files.append(item)
    # 按文件名排序，输出更整齐
    files.sort(key=lambda p: p.name)
    return files


def ensure_unique(target_path: Path) -> Path:
    """
    如果目标路径已存在，自动添加序号后缀避免覆盖。

    例如：
        课程通知.txt 已存在 → 课程通知_1.txt
        课程通知_1.txt 也存在 → 课程通知_2.txt

    Args:
        target_path: 期望的目标文件路径

    Returns:
        Path: 确保不重复的最终目标路径
    """
    if not target_path.exists():
        return target_path

    # 分离文件名主干和扩展名
    stem = target_path.stem       # 例如 "课程通知"
    suffix = target_path.suffix   # 例如 ".txt"
    parent = target_path.parent   # 目标目录

    counter = 1
    new_path = parent / f"{stem}_{counter}{suffix}"
    while new_path.exists():
        counter += 1
        new_path = parent / f"{stem}_{counter}{suffix}"

    return new_path


def generate_plan(source_dir: Path) -> list[dict]:
    """
    根据源目录中的文件和分类规则，生成整理计划。

    每个计划项是一个字典，包含：
        - source: 源文件 Path
        - filename: 文件名
        - category: 分类目录
        - target: 目标文件 Path（已解决重名）

    Args:
        source_dir: 源目录 Path 对象

    Returns:
        list[dict]: 整理计划列表
    """
    files = scan_source(source_dir)
    plan = []

    for file_path in files:
        category = get_category(file_path)
        plan.append({
            "source": file_path,
            "filename": file_path.name,
            "category": category,
        })

    return plan


def execute_plan(plan: list[dict], target_dir: Path, dry_run: bool = False) -> list[dict]:
    """
    执行整理计划。

    - dry_run=True: 只返回计划详情，不真正操作文件
    - dry_run=False: 创建目录、复制文件、生成 CSV 报告

    Args:
        plan: 整理计划列表
        target_dir: 目标目录 Path 对象
        dry_run: 是否为预览模式

    Returns:
        list[dict]: 执行结果列表（用于生成报告）
    """
    results = []

    # 统计各类文件数量
    category_count = {}

    for item in plan:
        category = item["category"]
        category_dir = target_dir / category
        target_path = category_dir / item["filename"]

        # 处理重名
        if not dry_run:
            category_dir.mkdir(parents=True, exist_ok=True)
            target_path = ensure_unique(target_path)
            shutil.copy2(item["source"], target_path)

        # 记录结果
        result = {
            "序号": len(results) + 1,
            "原路径": str(item["source"]),
            "目标路径": str(target_path),
            "分类": category,
            "文件名": item["filename"],
        }
        results.append(result)

        # 统计
        category_count[category] = category_count.get(category, 0) + 1

    # 非预览模式下生成 CSV 报告
    if not dry_run:
        write_csv_report(results, category_count, target_dir)

    return results, category_count


def write_csv_report(results: list[dict], category_count: dict, target_dir: Path) -> Path:
    """
    生成 CSV 格式的整理报告。

    报告包含两部分信息：
        1. 每个文件的来源和去向
        2. 各类文件的数量统计

    Args:
        results: 执行结果列表
        category_count: 分类统计字典
        target_dir: 目标目录

    Returns:
        Path: 报告文件路径
    """
    report_path = target_dir / "整理报告.csv"

    with open(report_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)

        # 报告标题
        writer.writerow(["课程资料整理报告"])
        writer.writerow(["生成时间", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
        writer.writerow(["操作类型", "复制（原文件保留）"])
        writer.writerow(["整理文件总数", len(results)])
        writer.writerow([])

        # 分类统计
        writer.writerow(["=" * 50])
        writer.writerow(["分类统计"])
        writer.writerow(["=" * 50])
        writer.writerow(["分类目录", "文件数量"])
        for category in sorted(category_count.keys()):
            writer.writerow([category, category_count[category]])
        writer.writerow([])

        # 文件明细
        writer.writerow(["=" * 50])
        writer.writerow(["文件整理明细"])
        writer.writerow(["=" * 50])
        writer.writerow(["序号", "文件名", "分类", "原路径", "目标路径"])

        for r in results:
            writer.writerow([
                r["序号"],
                r["文件名"],
                r["分类"],
                r["原路径"],
                r["目标路径"],
            ])

    return report_path


def print_plan(plan: list[dict], target_dir: Path) -> None:
    """
    在终端打印整理计划预览。

    Args:
        plan: 整理计划列表
        target_dir: 目标目录（用于显示目标路径）
    """
    print("=" * 60)
    print("【整理计划预览】--dry-run 模式，不会真正操作文件")
    print("=" * 60)

    for item in plan:
        category_dir = target_dir / item["category"]
        target_display = category_dir / item["filename"]
        print(f"  {item['filename']}")
        print(f"    分类: {item['category']}")
        print(f"    目标: {target_display}")
        print()

    print(f"共计 {len(plan)} 个文件待整理")
    print("=" * 60)


def print_summary(results: list[dict], category_count: dict) -> None:
    """
    在终端打印整理完成的摘要。

    Args:
        results: 执行结果列表
        category_count: 分类统计字典
    """
    print("=" * 60)
    print("【整理完成】")
    print("=" * 60)
    print(f"操作类型: 复制（原文件已保留）")
    print(f"整理文件总数: {len(results)}")
    print()
    print("分类统计:")
    for category in sorted(category_count.keys()):
        print(f"  {category}: {category_count[category]} 个文件")
    print()
    print(f"CSV 报告已生成: 整理报告.csv")
    print("=" * 60)
